# Extract config data from the file
lengths_file = open("Config.txt", "r").readlines()

max_length = float(lengths_file[3 - 1].split(": ")[1])
wood_type = lengths_file[4 - 1].split(": ")[1].split("\n")[0]


# Get lengths information from the file
lengths_start_line = 10 - 1
lengths = []

for line_index in range(lengths_start_line, len(lengths_file)):
  if lengths_file[line_index] != "": #<- If line is not empty
    # Get a list of the lengths
    new_lengths = lengths_file[line_index].split(", ")
    
    for new_length in new_lengths:
      # Deal with empty slots
      if new_length != "":
        # Handle multiples
        if "x" in new_length:
          length_info = new_length.split("x")
          item_length = float(length_info[1])
          num_items = int(length_info[0])
          
          for i in range(num_items):
            lengths.append(item_length)
        
        # Handle single numbers
        else:
          lengths.append(float(new_length))

buy_boards = [0]

# Adds every new length to the length of a board, to spread it out.
for length in lengths:
  
  board_found = False
  for index in range(len(buy_boards)):
    
    # Determine the remaining length on a board
    remaining_length = max_length - buy_boards[index]
  
    # If there is space for the new length we want to add, then add it to the board.
    if remaining_length >= float(length):
      buy_boards[index] = buy_boards[index] + float(length)
      buy_boards = sorted(buy_boards, reverse=True)
      board_found = True
      break
  
  # If there is no existing board with enough space, create a new one.
  if not board_found:
    buy_boards.append(float(length))
    
num_boards = len(buy_boards)

efficiency = (sum(buy_boards) / num_boards) / max_length * 100

print("You should purchase " + str(num_boards) + " " + wood_type + "x" + str(max_length) + " boards.")
print("This was calculated to be a " + str(efficiency) + "% efficient solution.")
print("\nThank you for using WoodCalculator today.")



