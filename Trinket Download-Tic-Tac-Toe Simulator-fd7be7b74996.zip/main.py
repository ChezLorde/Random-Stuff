file = open("results.txt","w")

def_grid = ["1", "2", "3", "4", "5", "6", '7', "8", "9"]

x_wins = 0
o_wins = 0

def save_grid(spots, x_wins, o_wins):
  pipe_sep = " | "
  line_sep = "---------"
  nl = "\n"
  wins_statement = "     Wins:  X   O"
  wins_buffer_1 =  "            "
  wins_buffer_2 = "   "
  
  message = spots[0] + pipe_sep + spots[1] + pipe_sep + spots[2] + nl + line_sep + wins_statement + nl + spots[3] + pipe_sep + spots[4] + pipe_sep + spots[5] +  wins_buffer_1 + str(x_wins) + wins_buffer_2 + str(o_wins) + nl + line_sep + nl + spots[6] + pipe_sep + spots[7] + pipe_sep + spots[8] 
  
  file.write(message)

def simulate_round():
  global x_wins, o_wins
  global def_grid
 
  grid = list(def_grid) #<- Get a new grid
  ended = False
  
  # Determine order and assignments
  file.write("MESSAGE assistant Would you like to go first, and would you like to be X or O?")
  
  player_mark = input("Select player mark ")
  bot_mark = input("Select bot mark ")
  
  first_player = input("Plays first? (X/O)")
  
  if bot_mark == first_player:
    bot_input = input("Select a space (bot)(" + bot_mark + ") ")
    grid[int(bot_input)-1] = bot_mark
    file.write('\nMESSAGE assistant """ Ok! I will go first. I will put mine on ' + bot_input + '. \n')
    save_grid(grid, x_wins, o_wins)
    file.write('\nYour turn! """')
  else:
    file.write('\nMESSAGE assistant """ Ok! You can go first. I will be ' + bot_mark + ' and you will be ' + player_mark + '. Choose the space you want to put your marker on.\n')
    save_grid(grid, x_wins, o_wins)
  
  # The game itself
  while not ended:
    
    # Take input for the player and bot's decisions
    user_input = input("Select a space (player) (" + player_mark + ")")
    bot_input = input("Select a space (bot) (" + bot_mark + ")")
    wins = input("Any wins? (X/O/D)")
    
    grid[int(user_input)-1] = player_mark
    grid[int(bot_input)-1] = bot_mark
    
    file.write("\nMESSAGE user " + user_input)
    file.write('\n\nMESSAGE assistant """ I will put mine on number ' + bot_input + ".\n")
    
    # Winning protocol
    if wins == bot_mark:
      ended = True
      x_wins += 1
      save_grid(grid, x_wins, o_wins)
      file.write("\nIt looks like I won! Good game! Would you like to play again?")
      
    elif wins == player_mark:
      ended = True
      o_wins += 1
      save_grid(grid, x_wins, o_wins)
      file.write("\nIt looks like you won! Good game! Would you like to play again?")
      
    elif wins == "D":
     ended = True
     save_grid(grid, x_wins, o_wins)
     file.write("\nIt looks like there was a draw! Would you like to play again?")
      
    else:
      save_grid(grid, x_wins, o_wins)
      file.write("\nYour turn now!")
    file.write('  """')


# Run the simulation
file.write("MESSAGE user Let's play a game of Tic-Tac-Toe.\n")

cont = True
while cont:
  simulate_round()
  cont = input("Play again? (Y/N)")
  if cont == "Y": 
    file.write("\nMESSAGE user Sure, let's play another round.\n")
  else:
    file.write("\nMESSAGE user No thanks.\n")
    file.write("\nMESSAGE assistant Okay, then. Bye!")

  

file.close()