import turtle

# This is used to verify my answer to the question, "There are 50 students standing in a circle. What number student is directly across from the sixth student?"

window = turtle.Screen()
pen = turtle.Turtle()

num_students_guess = 52
stored = {"5":[0,0,0], "31":[0,0,0], "36":[0,0,0], "26":[0,0,0]}

for i in range(num_students_guess):
  pen.forward(10)
  penx = pen.xcor()
  peny = pen.ycor()
  
  for key in stored.keys():
    if str(i) == key:
      stored[key] = [penx, peny, pen.heading()]
    
  pen.write(str(i),True,"center","10px Arial")
  pen.goto(penx, peny)
  pen.left(360/num_students_guess)

pen.up()
pen.goto(stored["5"][0], stored["5"][1])
pen.down()
pen.goto(stored["31"][0], stored["31"][1])

pen.up()
pen.goto(stored["36"][0], stored["36"][1])

pen.down()
pen.goto(stored["26"][0], stored["26"][1])

slope1 = (stored["5"][1] - stored["31"][1]) / (stored["5"][0] - stored["31"][0])
slope2 = (stored["26"][1] - stored["36"][1]) / (stored["26"][0] - stored["36"][0])

print("Diameter Slope: " + str(slope1))
print("Chord Slope: " + str(slope2))
print("Opposite Reciprocal of Chord Slope: " + str(-1 * (slope2 ** -1)))



window.mainloop()