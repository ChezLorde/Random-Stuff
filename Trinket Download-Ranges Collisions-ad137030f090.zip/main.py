import turtle
import math
import random

detec_dist = 2

joe = turtle.Turtle()
joe.color("red")
joe.speed(0)
player = turtle.Turtle()
window = turtle.Screen()
horizontalwalls = []
verticalwalls = []

def dist_between_points(x1, y1, x2, y2):
  dist_x = abs(x2 - x1)
  dist_y = abs(y2 - y1)
  dist = math.sqrt(dist_x * dist_x + dist_y * dist_y)
  return dist

def is_too_close(value1, value2):
  if abs(value1 - value2) < detec_dist:
    return True
  else:
    return False

def forward_wall(distance):
  global walls
  
  if joe.heading() == 0 or joe.heading() == 180:
    y_value = int(joe.ycor())
    start_x_value = int(joe.xcor())
    joe.forward(distance)
    end_x_value = int(joe.xcor())
    
    if start_x_value > end_x_value:
      end_x_value = start_x_value
      start_x_value = int(joe.xcor())
    
    horizontalwalls.append([y_value, start_x_value, end_x_value])
    print("New Horiz Wall: " + "y: " + str(y_value) + " x: " + str(start_x_value) + " to " + str(end_x_value))
    
  elif joe.heading() == 90 or joe.heading() == 270:
    x_value = int(joe.xcor())
    start_y_value = int(joe.ycor())
    joe.forward(distance)
    end_y_value = int(joe.ycor())
    
    if start_y_value > end_y_value:
      end_y_value = start_y_value
      start_y_value = int(joe.ycor())
    
    verticalwalls.append([x_value, start_y_value, end_y_value])
    print("New Vertical Wall: " + "x: " + str(x_value) + " x: " + str(start_y_value) + " to " + str(end_y_value))
  
  else:
    joe.forward(distance)
  
  
  
def forward_player(distance):
  global walls
  
  for amount_gone in range(distance):

    touching_wall = False
    player.forward(1)
    
    #if player.heading() == 0 or player.heading() == 180: #horizontal player: intersects w vertical
    
    for rg in verticalwalls:
     
      wall_x = rg[0]
      wall_y_start = rg[1]
      wall_y_end = rg[2]
     
      if is_too_close(wall_x, player.xcor()):
          if player.ycor() < wall_y_end and player.ycor() > wall_y_start:
            touching_wall = True
            break
    
    #elif player.heading() == 90 or player.heading() == 270: #vertical player: intersects w horizontal

    for rg in horizontalwalls:
       wall_y = rg[0]
       wall_x_start = rg[1]
       wall_x_end = rg[2]
       
       if is_too_close(wall_y, player.ycor()):
          if player.xcor() < wall_x_end and player.xcor() > wall_x_start:
            touching_wall = True
            break
    
    if touching_wall:
      player.backward(1)
      break
      
  print("Amount Gone: ", amount_gone)

joe.penup()
joe.goto(50, -50)
joe.pendown()
for i in range(4):
  joe.left(90)
  forward_wall(100)
  
player.setheading(random.randint(0, 359))
#player.goto(0, 5)
forward_player(150)


window.listen()
window.mainloop()