letters = "a b c d e f g h i j k l m n o p q r s t u v w x y z".split(" ")
total_input = "VA BEQRE GB SVAQ GUR XRL, LBH ZHFG SBYYBJ GUR JUVGR ENOOVG"
input1 = "va"

import random

# Necessary for Affine decryption
def mod_inverse(a, m):
    a = a % m
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

'''
# Caesar Cipher
for ltr in input1:
  x = letters.index(ltr)
  y = (x + 5) % 26
  output1 = output1 + letters[y]
'''

# Affine Cipher
def affine_enc(input1, a, b):
  global letters
  output1 = ""
  for ltr in input1:
    x = letters.index(ltr)
    y = (a * x + b) % 26
    output1 = output1 + letters[y]
  return output1
  
# Affine Decrypt
def affine_dec(input1, a, b):
  global letters
  output1 = ""
  for ltr in input1:
    x = letters.index(ltr)
    y = int((((x - b) % 26) * mod_inverse(a, 26)) % 26)
    output1 = output1 + letters[y]
  return output1

# Vignenere Cipher
def vig_enc(input1, key):
  global letters
  output1 = ""
  for i in range(len(input1)):
    key_ltr = key[i % len(key)]
    key_row = letters[letters.index(key_ltr):len(letters)] + letters[0:(letters.index(key_ltr))]
  
    output1 = output1 + key_row[letters.index(input1[i])]
  return output1
  
# Vignenere Decryption
def vig_dec(input1, key):
  global letters
  output1 = ""
  for i in range(len(input1)):
    key_ltr = key[i % len(key)]
    key_row = letters[letters.index(key_ltr):len(letters)] + letters[0:(letters.index(key_ltr))]
  
    output1 = output1 + letters[key_row.index(input1[i])]
  return output1

# Custom Encryption
def cust_enc(input1, a1, b1, a2, b2):
  primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
  encrypt1 = affine_enc(input1, a1, b1)
  #print(encrypt1)
  key = ""
  for i in primes:
    if i <= len(encrypt1):
      ltr = random.choice(letters)
      key = key + ltr
  #print("key: " + key)
  encrypt2 = vig_enc(encrypt1, key)
  #print(encrypt2)
  encrypt3 = encrypt2
  for i in range(len(key)):
    encrypt3 = encrypt3[0:primes[i] - 1] + key[i] + encrypt3[primes[i] - 1:len(encrypt3)]
  #print(encrypt3)
  encrypt4 = affine_enc(encrypt3, a2, b2)
  print(encrypt4)
  return encrypt4


# Custom Decryption
def cust_dec(input1, a1, b1, a2, b2):
  #print("-------")
  #print(input1)
  primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
  encrypt4 = affine_dec(input1, a2, b2)
  #print(encrypt4)
  encrypt3 = encrypt4
  key = ""
  for i in range(len(primes)):
    if primes[i + 1] < len(encrypt3):
      key = key + encrypt4[primes[i] - 1]
  
      encrypt3 = encrypt3[0:primes[i] - 1] + " " + encrypt3[primes[i]:len(encrypt3)]
      #print(encrypt3, primes[i] - 1, encrypt4[primes[i] - 1])
    else:
      break
  encrypt3 = "".join(encrypt3.split(" "))
  #print(encrypt3)
  #print("key: "+key)
  encrypt2 = vig_dec(encrypt3,key)
  #print(encrypt2)
  encrypt1 = affine_dec(encrypt2, a1, b1)
  print(encrypt1)
  return encrypt1
  
    
  
  
    
  


'''
encrypt1 = vig_enc(input1,"josh")
print(encrypt1)
print(vig_dec(encrypt1,"josh"))'''

print(vig_dec(input1,"follow"))

'''
# Custom cipher idea encrypt: Affine, Encrypt origninal message using key, Embed random key in prime positions, 
#cipher = cust_enc(input1, 1, 2, 3, 4)
#print(cipher, affine_dec(cipher, 9, 2))

a1 = int(input("a1 --->  "))
b1 = int(input("b1 --->  "))
a2 = int(input("a2 --->  "))
b2 = int(input("b2 --->  "))
input1 = input("Text --->   ")
  
if input("Encrypt of Decrypt (e or d) --->   ") == "e":
  cust_enc(input1, a1, b1, a2, b2)
else:
  cust_dec(input1, a1, b1, a2, b2)'''









